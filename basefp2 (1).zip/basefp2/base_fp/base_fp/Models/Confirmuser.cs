﻿namespace base_fp.Models
{
    public class ConfirmUserModel
    {
        public string Email { get; set; }
    }
}
